<!-- Topbar Start -->
<div class="container-fluid">
    <div class="row" style="background-color: #ff999a">
        <div class="col-md-12">
            <div id="success-register" data-success="<?php echo e(session('success')); ?>"><?php echo e(session('success')); ?></div>

            <div class="locale">
                <?php if(session('locale') == 'vi' || session('locale') == null): ?>
                    <a class="text-body mr-3" href="<?php echo e(route('language', ['locale' => 'kr'])); ?>"><img
                                src="<?php echo e(asset('images/korea.png')); ?>" alt=""></a>
                    <a class="text-body mr-3" href="<?php echo e(route('language', ['locale' => 'jp'])); ?>"><img
                                src="<?php echo e(asset('images/japan.webp')); ?>" alt=""></a>
                    <a class="text-body mr-3" href="<?php echo e(route('language', ['locale' => 'cn'])); ?>"><img
                                src="<?php echo e(asset('images/china.webp')); ?>" alt=""></a>
                <?php endif; ?>
                <?php if(session('locale') == 'kr'): ?>
                    <a class="text-body mr-3" href="<?php echo e(route('language', ['locale' => 'vi'])); ?>"><img
                                src="<?php echo e(asset('images/vietnam.webp')); ?>" alt=""></a>
                    <a class="text-body mr-3" href="<?php echo e(route('language', ['locale' => 'jp'])); ?>"><img
                                src="<?php echo e(asset('images/japan.webp')); ?>" alt=""></a>
                    <a class="text-body mr-3" href="<?php echo e(route('language', ['locale' => 'cn'])); ?>"><img
                                src="<?php echo e(asset('images/china.webp')); ?>" alt=""></a>
                <?php endif; ?>
                <?php if(session('locale') == 'jp'): ?>
                    <a class="text-body mr-3" href="<?php echo e(route('language', ['locale' => 'vi'])); ?>"><img
                                src="<?php echo e(asset('images/vietnam.webp')); ?>" alt=""></a>
                    <a class="text-body mr-3" href="<?php echo e(route('language', ['locale' => 'kr'])); ?>"><img
                                src="<?php echo e(asset('images/korea.png')); ?>" alt=""></a>
                    <a class="text-body mr-3" href="<?php echo e(route('language', ['locale' => 'cn'])); ?>"><img
                                src="<?php echo e(asset('images/china.webp')); ?>" alt=""></a>
                <?php endif; ?>
                <?php if(session('locale') == 'cn'): ?>
                    <a class="text-body mr-3" href="<?php echo e(route('language', ['locale' => 'vi'])); ?>"><img
                                src="<?php echo e(asset('images/vietnam.webp')); ?>" alt=""></a>
                    <a class="text-body mr-3" href="<?php echo e(route('language', ['locale' => 'kr'])); ?>"><img
                                src="<?php echo e(asset('images/korea.png')); ?>" alt=""></a>
                    <a class="text-body mr-3" href="<?php echo e(route('language', ['locale' => 'jp'])); ?>"><img
                                src="<?php echo e(asset('images/japan.webp')); ?>" alt=""></a>
                <?php endif; ?>

            </div>
        </div>
    </div>
    <div class="row align-items-center">
        <div class="col-3 pl-5" id="nav-left" style="background-color: #ffcccc">
            <div class="row">
                <a href="/" class="text-decoration-none">
                    <span class="h1 text-uppercase text-primary bg-dark px-2">Shopping</span>
                    <span class="h1 text-uppercase text-dark bg-primary px-2 ml-n1">Mall</span>
                </a>
            </div>
        </div>
        <div class="col-9 py-2 pr-5" id="nav-right" style="background-color: #feff99;">
            <div class="row align-items-center ">
                <div class="col-1"></div>
                <div class="col-5">
                    <form>
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="<?php echo e(__('home.placeholder search')); ?>">
                            <div class="input-group-append bg-white">
                            <span type="button" class="input-group-text bg-transparent text-primary ">
                                <?php echo e(__('home.search')); ?>

                            </span>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-1"></div>

                <div class="col-5 pr-5">
                    <div class="row align-items-center -align-right">
                        <div class="col-1"></div>
                        <?php if(session('error')): ?>
                            <?php echo e(session('error')); ?>

                        <?php endif; ?>

                        <?php if(session('login')): ?>
                            <div class="col-6">

                                <div class="row" style="display: flex; align-items: center;">
                                    <div class="col-4">
                                        <a href="#!">
                                            <img class="avatar"
                                                 src="https://www.gravatar.com/avatar/4f7f74d163a190dee16e31dffc8da4e5?d=mm&amp;s=64"
                                                 alt=""/>
                                        </a>
                                    </div>
                                    <div class="col-8">
                                        <div class="dropdown d-flex align-items-center">
                                            <h4 data-toggle="dropdown" aria-expanded="false">
                                                <?php if($infoUser): ?>
                                                    <?php echo e($infoUser->name); ?>

                                                <?php endif; ?>
                                            </h4>
                                            <div class="dropdown-menu">
                                                <a class="dropdown-item" href="#">Action</a>
                                                <a class="dropdown-item" href="#">Another action</a>
                                                <form action="<?php echo e(route('logout')); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit">Đăng xuất</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                            </div>
                        <?php else: ?>
                            <div class="col-3">

                                <div class="btn-group mb-2 full-width">
                                    <a href="/login" class="full-width">
                                        <button type="button" class="btn btn-warning mr-2 full-width"
                                                aria-expanded="false"><?php echo e(__('home.sign in')); ?></button>
                                    </a>
                                </div>
                                <div class="btn-group full-width">
                                    <a href="" class="full-width">
                                        <button type="button" class="btn btn-danger mr-2 full-width"
                                                aria-expanded="false">
                                            button 1
                                        </button>
                                    </a>
                                </div>

                            </div>
                            <div class="col-3">
                                <div class="btn-group mb-2 full-width">
                                    <a href="/register" class="full-width">
                                        <button type="button" class="btn btn-success mr-2 full-width"
                                                aria-expanded="false"><?php echo e(__('home.sign up')); ?></button>
                                    </a>
                                </div>
                                <div class="btn-group full-width">
                                    <a href="" class="full-width">
                                        <button type="button" class="btn btn-info mr-2 full-width"
                                                aria-expanded="false">
                                            button 2
                                        </button>
                                    </a>
                                </div>
                            </div>
                        <?php endif; ?>

                        <div class="col-4 pr-5">
                            <img src="<?php echo e(asset('images/hotline.png')); ?>" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Topbar End -->

<script>
    window.addEventListener('load', function () {
        var col9Height = document.querySelector('#nav-right').clientHeight;
        var col3Height = document.querySelector('#nav-left').clientHeight;
        document.querySelector('#nav-left').style.padding = (col9Height / 2 - col3Height / 2) + 'px';
    });
</script>
<?php /**PATH /Volumes/Workspace/ilglobal/shopping-mall/resources/views/frontend/layouts/partials/header.blade.php ENDPATH**/ ?>