<?php $__env->startSection('title', 'Profile'); ?>

<?php $__env->startSection('content'); ?>
    <style>
        body {
            background-color: #ebebeb;
        }
    </style>

    <div class="container">
        <div class="row">
            <div class="col-3 ">
                <?php echo $__env->make('frontend.pages.profile.side-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col-9 ">
                <?php echo $__env->yieldContent('sub-content'); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Workspace/ilglobal/shopping-mall/resources/views/frontend/layouts/profile.blade.php ENDPATH**/ ?>