<ul class="submenu dropdown-menu">
    <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($subcategory->name); ?>

        <?php if($subcategory->children->count() > 0): ?>
            <?php echo $__env->make('frontend.categories.partials.subcategories', ['subcategories' => $subcategory->children], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH /Volumes/Workspace/ilglobal/shopping-mall/resources/views/frontend/layouts/partials/subcategories.blade.php ENDPATH**/ ?>