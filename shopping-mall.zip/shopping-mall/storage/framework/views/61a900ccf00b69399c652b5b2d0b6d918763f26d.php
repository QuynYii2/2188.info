<?php $__env->startSection('title', 'Home page'); ?>

<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/index.css')); ?>">
    <!-- Carousel Start -->
    <div style="background-color: #ffccff; height: 30px" class="text-center-x-y">전체카테고리</div>
    <div class="container-fluid" style="background: #ffcccc">
        <div class="row">
            <div class="col-3">
                <div class="row">
                    <div class="col-7">
                        <div class="row bg-light border-product">
                            <img class="img-fluid w-100 p-3" src="<?php echo e(asset('images/left-cate.png')); ?>" alt="">
                        </div>
                        <div class="row bg-light mt-1 border-product text-center-x-y" style="height: 205px">
                            <h4>
                                행외시장개척
                                <br>
                                <br>
                                해외고객발굴
                            </h4>
                        </div>
                    </div>
                    <div class="col-5">
                        <div class="nav-item dropdown" id="fixMenu">
                            <button class="btn bg-white w-100 dropdown-toggle-split" type="button"
                                    data-toggle="dropdown"
                                    aria-expanded="true">
                                <?php echo e(__('home.category')); ?>

                            </button>
                            <ul class="dropdown-menu show" id="dropdown">
                                <li><a class="dropdown-item" href="/category/10"> Dropdown item 2 &raquo </a>
                                    <ul class="submenu dropdown-menu">
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a class="dropdown-item" href=""><?php echo e($category->name); ?> <?php if($category->children->count() > 0): ?>&raquo <?php endif; ?> </a>
                                            <?php if($category->children->count() > 0): ?>
                                                <?php echo $__env->make('frontend.layouts.partials.subcategories', ['subcategories' => $category->children], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            <?php endif; ?>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6" style="padding: 0">
                <div id="header-carousel" class="carousel slide carousel-fade " data-ride="carousel">
                    <ol class="carousel-indicators">
                        <li data-target="#header-carousel" data-slide-to="0" class="active"></li>
                        <li data-target="#header-carousel" data-slide-to="1"></li>
                        <li data-target="#header-carousel" data-slide-to="2"></li>
                    </ol>
                    <div class="carousel-inner">
                        <div class="carousel-item position-relative active" style="height: 450px;">
                            <img class="position-absolute w-100 h-100" src="<?php echo e(asset('images//carousel-1.jpg')); ?>"
                                 style="object-fit: cover;">
                        </div>
                        <div class="carousel-item position-relative" style="height: 450px;">
                            <img class="position-absolute w-100 h-100" src="<?php echo e(asset('images//carousel-2.jpg')); ?>"
                                 style="object-fit: cover;">
                        </div>
                        <div class="carousel-item position-relative" style="height: 450px;">
                            <img class="position-absolute w-100 h-100" src="<?php echo e(asset('images//carousel-3.jpg')); ?>"
                                 style="object-fit: cover;">
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-3" style="padding: 0">
                <div class="product-offer " style="height: 150px;">
                    <img class="img-fluid" src="<?php echo e(asset('images//offer-1.jpg')); ?>" alt="">
                </div>
                <div class="product-offer " style="height: 100px;">
                    <img class="img-fluid" src="<?php echo e(asset('images//product-3.jpg')); ?>" alt="">
                </div>
                <div class="product-offer " style="height: 200px;">
                    <img class="img-fluid" src="<?php echo e(asset('images//offer-2.jpg')); ?>" alt="">
                </div>
            </div>
        </div>
        <p class="text-center">추천신상품</p>
    </div>
    <!-- Carousel End -->

    <!-- Products Start -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-2">
                <div class="row ">
                    <div class="col-11">
                        <div class="pb-2">
                            <div class="product-item bg-light border-product">
                                <div class="text-center-x-y height-side">
                                    <h4>
                                        物流最强者!
                                        <br>
                                        <br>
                                        爱尔国际物流
                                        <br>
                                        有限公司
                                    </h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-11">
                        <div class="product-item bg-light border-product">
                            <div class="product-img position-relative overflow-hidden">
                                <img class="img-fluid w-100" src="<?php echo e(asset('images/product-1.jpg')); ?>"
                                     alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="/detail/1">Product Name Goes
                                    123123123Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-8">
                <div class="row py-2">
                    <?php $__currentLoopData = $productByLocal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-auto rounded">
                            <div class="product-item bg-light rounded ">
                                <div class="product-img position-relative overflow-hidden rounded">
                                    <img class=" height-img w-100" src="<?php echo e($product->thumbnail); ?>" alt="">
                                    <div class="product-action">
                                        <a class="btn btn-outline-dark btn-square" href=""><i
                                                    class="fa fa-shopping-cart"></i></a>
                                        <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                        <a class="btn btn-outline-dark btn-square" href=""><i
                                                    class="fa fa-sync-alt"></i></a>
                                    </div>
                                </div>
                                <div class="text-center py-4 text-limit">
                                    <a class="h6 text-decoration-none text-truncate" href=""><?php echo e($product->name); ?></a>
                                    <div class="d-flex align-items-center justify-content-center mt-2">
                                        <h5><?php echo e(convertCurrency($product->price, $countryCode)); ?>

                                        </h5><h6 class="text-muted ml-2"></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div class="col-2">
                <div class="row ">
                    <div class="col-1"></div>
                    <div class="col-11">
                        <div class="pb-2">
                            <div class="product-item bg-light border-product">
                                <div class="text-center-x-y height-side">
                                    <h4 style="line-height: 50px; ">
                                        网上购物中心
                                        <br>
                                        入 驻
                                        <br>
                                        销 售
                                        <br>
                                        管 理
                                    </h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-1"></div>
                    <div class="col-11">
                        <div class="product-item bg-light border-product">
                            <div class="product-img position-relative overflow-hidden">
                                <img class="img-fluid w-100 " src="<?php echo e(asset('images/product-1.jpg')); ?>"
                                     alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">123Product1231 Name Goes
                                    Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="pt-5 pb-2" style="background: #ff66ff"></div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-2">
                <div class="row pb-2">
                    <div class="col-11 ">
                        <div class="product-item bg-light border-product">
                            <div class="product-img position-relative overflow-hidden">
                                <img class="img-fluid w-100" src="<?php echo e(asset('images/product-1.jpg')); ?>"
                                     alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes
                                    123123123Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row pb-2">
                    <div class="col-11">
                        <div class="product-item bg-light border-product">
                            <div class="product-img position-relative overflow-hidden">
                                <img class="img-fluid w-100" src="<?php echo e(asset('images/product-2.jpg')); ?>"
                                     alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes
                                    123123123Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-8">
                <div class="row py-2">
                    <div class="col-auto">

                        <div class="product-item bg-light rounded ">
                            <div class="product-img position-relative overflow-hidden rounded">
                                <img class="custom-flag"
                                     src="<?php echo e(asset('images/china.webp')); ?>"
                                     alt="">
                                <img class=" height-img w-100" src="<?php echo e(asset('images/product-3.jpg')); ?>" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="product-item bg-light rounded ">
                            <div class="product-img position-relative overflow-hidden rounded">
                                <img class=" height-img w-100" src="<?php echo e(asset('images/product-4.jpg')); ?>" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="product-item bg-light rounded ">
                            <div class="product-img position-relative overflow-hidden rounded">
                                <img class=" height-img w-100" src="<?php echo e(asset('images/product-7.jpg')); ?>" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="product-item bg-light rounded ">
                            <div class="product-img position-relative overflow-hidden rounded">
                                <img class=" height-img w-100" src="<?php echo e(asset('images/product-6.jpg')); ?>" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="product-item bg-light rounded ">
                            <div class="product-img position-relative overflow-hidden rounded">
                                <img class=" height-img w-100" src="<?php echo e(asset('images/product-5.jpg')); ?>" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row pt-3">
                    <div class="col-auto">

                        <div class="product-item bg-light rounded ">
                            <div class="product-img position-relative overflow-hidden rounded">
                                <img class=" height-img w-100" src="<?php echo e(asset('images/product-3.jpg')); ?>" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="product-item bg-light rounded ">
                            <div class="product-img position-relative overflow-hidden rounded">
                                <img class=" height-img w-100" src="<?php echo e(asset('images/product-4.jpg')); ?>" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="product-item bg-light rounded ">
                            <div class="product-img position-relative overflow-hidden rounded">
                                <img class=" height-img w-100" src="<?php echo e(asset('images/product-7.jpg')); ?>" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="product-item bg-light rounded ">
                            <div class="product-img position-relative overflow-hidden rounded">
                                <img class=" height-img w-100" src="<?php echo e(asset('images/product-6.jpg')); ?>" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="product-item bg-light rounded ">
                            <div class="product-img position-relative overflow-hidden rounded">
                                <img class=" height-img w-100" src="<?php echo e(asset('images/product-5.jpg')); ?>" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-2">
                <div class="row pb-2">
                    <div class="col-1"></div>
                    <div class="col-11">
                        <div class="product-item bg-light border-product">
                            <div class="product-img position-relative overflow-hidden">
                                <img class="img-fluid w-100 " src="<?php echo e(asset('images/product-8.jpg')); ?>"
                                     alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">123Product1231 Name Goes
                                    Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row pb-2">
                    <div class="col-1"></div>
                    <div class="col-11">
                        <div class="product-item bg-light border-product">
                            <div class="product-img position-relative overflow-hidden">
                                <img class="img-fluid w-100 " src="<?php echo e(asset('images/product-9.jpg')); ?>"
                                     alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">123Product1231 Name Goes
                                    Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-2">
                <div class="row pb-2">
                    <div class="col-11 ">
                        <div class="product-item bg-light border-product">
                            <div class="product-img position-relative overflow-hidden">
                                <img class="img-fluid w-100" src="<?php echo e(asset('images/product-1.jpg')); ?>"
                                     alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes
                                    123123123Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row pb-2">
                    <div class="col-11">
                        <div class="product-item bg-light border-product">
                            <div class="product-img position-relative overflow-hidden">
                                <img class="img-fluid w-100" src="<?php echo e(asset('images/product-2.jpg')); ?>"
                                     alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes
                                    123123123Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-8">
                <div class="row py-2">
                    <div class="col-auto">

                        <div class="product-item bg-light rounded ">
                            <div class="product-img position-relative overflow-hidden rounded">
                                <img class="custom-flag"
                                     src="<?php echo e(asset('images/japan.webp')); ?>"
                                     alt="">
                                <img class=" height-img w-100" src="<?php echo e(asset('images/product-3.jpg')); ?>" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="product-item bg-light rounded ">
                            <div class="product-img position-relative overflow-hidden rounded">
                                <img class=" height-img w-100" src="<?php echo e(asset('images/product-4.jpg')); ?>" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="product-item bg-light rounded ">
                            <div class="product-img position-relative overflow-hidden rounded">
                                <img class=" height-img w-100" src="<?php echo e(asset('images/product-7.jpg')); ?>" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="product-item bg-light rounded ">
                            <div class="product-img position-relative overflow-hidden rounded">
                                <img class=" height-img w-100" src="<?php echo e(asset('images/product-6.jpg')); ?>" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="product-item bg-light rounded ">
                            <div class="product-img position-relative overflow-hidden rounded">
                                <img class=" height-img w-100" src="<?php echo e(asset('images/product-5.jpg')); ?>" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row pt-3">
                    <div class="col-auto">

                        <div class="product-item bg-light rounded ">
                            <div class="product-img position-relative overflow-hidden rounded">
                                <img class=" height-img w-100" src="<?php echo e(asset('images/product-3.jpg')); ?>" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="product-item bg-light rounded ">
                            <div class="product-img position-relative overflow-hidden rounded">
                                <img class=" height-img w-100" src="<?php echo e(asset('images/product-4.jpg')); ?>" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="product-item bg-light rounded ">
                            <div class="product-img position-relative overflow-hidden rounded">
                                <img class=" height-img w-100" src="<?php echo e(asset('images/product-7.jpg')); ?>" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="product-item bg-light rounded ">
                            <div class="product-img position-relative overflow-hidden rounded">
                                <img class=" height-img w-100" src="<?php echo e(asset('images/product-6.jpg')); ?>" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="product-item bg-light rounded ">
                            <div class="product-img position-relative overflow-hidden rounded">
                                <img class=" height-img w-100" src="<?php echo e(asset('images/product-5.jpg')); ?>" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-2">
                <div class="row pb-2">
                    <div class="col-1"></div>
                    <div class="col-11">
                        <div class="product-item bg-light border-product">
                            <div class="product-img position-relative overflow-hidden">
                                <img class="img-fluid w-100 " src="<?php echo e(asset('images/product-8.jpg')); ?>"
                                     alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">123Product1231 Name Goes
                                    Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row pb-2">
                    <div class="col-1"></div>
                    <div class="col-11">
                        <div class="product-item bg-light border-product">
                            <div class="product-img position-relative overflow-hidden">
                                <img class="img-fluid w-100 " src="<?php echo e(asset('images/product-9.jpg')); ?>"
                                     alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">123Product1231 Name Goes
                                    Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-2">
                <div class="row pb-2">
                    <div class="col-11 ">
                        <div class="product-item bg-light border-product">
                            <div class="product-img position-relative overflow-hidden">
                                <img class="img-fluid w-100" src="<?php echo e(asset('images/product-1.jpg')); ?>"
                                     alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes
                                    123123123Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row pb-2">
                    <div class="col-11">
                        <div class="product-item bg-light border-product">
                            <div class="product-img position-relative overflow-hidden">
                                <img class="img-fluid w-100" src="<?php echo e(asset('images/product-2.jpg')); ?>"
                                     alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes
                                    123123123Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-8">
                <div class="row py-2">
                    <div class="col-auto">

                        <div class="product-item bg-light rounded ">
                            <div class="product-img position-relative overflow-hidden rounded">
                                <img class="custom-flag"
                                     src="<?php echo e(asset('images/vietnam.webp')); ?>"
                                     alt="">
                                <img class=" height-img w-100" src="<?php echo e(asset('images/product-3.jpg')); ?>" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="product-item bg-light rounded ">
                            <div class="product-img position-relative overflow-hidden rounded">
                                <img class=" height-img w-100" src="<?php echo e(asset('images/product-4.jpg')); ?>" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="product-item bg-light rounded ">
                            <div class="product-img position-relative overflow-hidden rounded">
                                <img class=" height-img w-100" src="<?php echo e(asset('images/product-7.jpg')); ?>" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="product-item bg-light rounded ">
                            <div class="product-img position-relative overflow-hidden rounded">
                                <img class=" height-img w-100" src="<?php echo e(asset('images/product-6.jpg')); ?>" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="product-item bg-light rounded ">
                            <div class="product-img position-relative overflow-hidden rounded">
                                <img class=" height-img w-100" src="<?php echo e(asset('images/product-5.jpg')); ?>" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row pt-3">
                    <div class="col-auto">

                        <div class="product-item bg-light rounded ">
                            <div class="product-img position-relative overflow-hidden rounded">
                                <img class=" height-img w-100" src="<?php echo e(asset('images/product-3.jpg')); ?>" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="product-item bg-light rounded ">
                            <div class="product-img position-relative overflow-hidden rounded">
                                <img class=" height-img w-100" src="<?php echo e(asset('images/product-4.jpg')); ?>" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="product-item bg-light rounded ">
                            <div class="product-img position-relative overflow-hidden rounded">
                                <img class=" height-img w-100" src="<?php echo e(asset('images/product-7.jpg')); ?>" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="product-item bg-light rounded ">
                            <div class="product-img position-relative overflow-hidden rounded">
                                <img class=" height-img w-100" src="<?php echo e(asset('images/product-6.jpg')); ?>" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="product-item bg-light rounded ">
                            <div class="product-img position-relative overflow-hidden rounded">
                                <img class=" height-img w-100" src="<?php echo e(asset('images/product-5.jpg')); ?>" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">Product Name Goes Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-2">
                <div class="row pb-2">
                    <div class="col-1"></div>
                    <div class="col-11">
                        <div class="product-item bg-light border-product">
                            <div class="product-img position-relative overflow-hidden">
                                <img class="img-fluid w-100 " src="<?php echo e(asset('images/product-8.jpg')); ?>"
                                     alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">123Product1231 Name Goes
                                    Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row pb-2">
                    <div class="col-1"></div>
                    <div class="col-11">
                        <div class="product-item bg-light border-product">
                            <div class="product-img position-relative overflow-hidden">
                                <img class="img-fluid w-100 " src="<?php echo e(asset('images/product-9.jpg')); ?>"
                                     alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-shopping-cart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="far fa-heart"></i></a>
                                    <a class="btn btn-outline-dark btn-square" href=""><i
                                                class="fa fa-sync-alt"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-4 text-limit">
                                <a class="h6 text-decoration-none text-truncate" href="">123Product1231 Name Goes
                                    Here</a>
                                <div class="d-flex align-items-center justify-content-center mt-2">
                                    <h5>$123.00</h5><h6 class="text-muted ml-2"></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- Products End -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Workspace/ilglobal/shopping-mall/resources/views/frontend/index.blade.php ENDPATH**/ ?>