@extends('layouts.admin')

@section('content')
    <!-- Nội dung trang danh sách danh mục -->
@endsection
