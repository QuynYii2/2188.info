@extends('layouts.admin')

@section('content')
    <!-- Form chỉnh sửa thông tin danh mục -->
@endsection
