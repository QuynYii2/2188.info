@extends('layouts.admin')

@section('content')
    <!-- Form tạo danh mục mới -->
@endsection
