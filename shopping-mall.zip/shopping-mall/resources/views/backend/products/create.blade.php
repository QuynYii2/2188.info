@extends('layouts.admin')

@section('content')
    <!-- Form tạo sản phẩm mới -->
@endsection
