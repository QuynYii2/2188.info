@extends('layouts.admin')

@section('content')
    <!-- Nội dung trang danh sách sản phẩm -->
@endsection
