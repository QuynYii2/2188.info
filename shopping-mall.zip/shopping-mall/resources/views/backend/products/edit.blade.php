@extends('layouts.admin')

@section('content')
    <!-- Form chỉnh sửa thông tin sản phẩm -->
@endsection
