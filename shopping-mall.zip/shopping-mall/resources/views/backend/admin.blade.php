<!DOCTYPE html>
<html>
<head>
    <title>Admin Panel</title>
    <!-- Thêm các tài nguyên CSS và JS cần thiết -->
</head>
<body>
<header>
    <!-- Phần header của trang -->
</header>

<nav>
    <!-- Phần menu điều hướng -->
</nav>

<div id="content">
    @yield('content')
</div>

<footer>
    <!-- Phần footer của trang -->
</footer>

<!-- Thêm các tài nguyên JS cuối trang cần thiết -->
</body>
</html>
