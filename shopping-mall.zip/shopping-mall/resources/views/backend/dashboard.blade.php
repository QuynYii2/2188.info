@extends('layouts.admin')

@section('content')
    <!-- Nội dung trang dashboard -->
@endsection
