@extends('frontend.layouts.profile')

@section('title', 'My Review')

@section('sub-content')
    <div class="row mt-5 bg-white rounded">
        <div class="row rounded pt-1">
            <h5>{{ __('home.my review') }}</h5>
        </div>
        <div class="border-bottom"></div>
        <div class="col-xs-12">
            <div class="tab-content py-3 px-3 px-sm-0">
                <div class="text-center">
                    <img src="{{asset('images/empty.jpg')}}" alt="">
                    <p>
                        Viết nhận xét với sản phẩm bạn đã sử dụng để cung cấp thông tin hữu ích cho mọi người
                    </p>
                </div>
            </div>

        </div>
    </div>
@endsection
