<?php

return [
    'welcome' => 'Xin Chào',
    'about' => 'Giới thiệu',
    'contact' => 'Liên hệ',
    'search' => 'Tìm kiếm',
    'placeholder search' => 'Tìm kiếm sản phẩm',
    'sign in' => 'Đăng nhập',
    'sign up' => 'Đăng ký',
    'seller' => 'Người bán',
    'buyer' => 'Người mua',
    'category' => 'Danh mục sản phẩm',

    'input name' => 'Nhập vào tên...',
    'input phone' => 'Nhập vào số điện thoại...',
    'input password' => 'Nhập vào mật khẩu...',
    'input email' => 'Nhập vào email...',
    'input address' => 'Nhập vào địa chỉ...',
    'input taxCode' => 'Nhập vào mã số thuế...',
    'input category' => 'Chọn danh mục sản phẩm...',
    'input nameProduct' => 'Nhập vào tên sản phẩm...',
    'input socialNetwork' => 'Nhập vào id mạng xã hội...',
    'input username' => 'Nhập vào tên đăng nhập...',
    'or use a social network' => 'Hoặc sử dụng mạng xã hội',
    'business license' => 'Tải lên giấy phép kinh doanh',

    //thông tin tài khoản, thông báo của tôi, quản lý đơn hàng, quản lý đổi trả, sổ địa chỉ, thông tin thanh toán, đánh giá sản phẩm, sản phẩm bạn đã xem, sản phẩm yêu thích, sản phẩm mua sau, nhận xét của tôi, chia sẻ có lời, hợp đồng bảo hiểm, mua trước trả sau, mã giảm giá, quản lý xu của tôi, bookcare của tôi
    'account information' => 'Thông tin tài khoản',
    'my notification' => 'Thông báo của tôi',
    'order management' => 'Quản lý đơn hàng',
    'return management' => 'Quản lý đổi trả',
    'address book' => 'Sổ địa chỉ',
    'payment information' => 'Thông tin thanh toán',
    'product evaluation' => 'Đánh giá sản phẩm',
    'product viewed' => 'Sản phẩm bạn đã xem',
    'favorite product' => 'Sản phẩm yêu thích',
    'product to buy later' => 'Sản phẩm mua sau',
    'my review' => 'Nhận xét của tôi',
    'share with profit' => 'Chia sẻ có lời',
    'insurance contract' => 'Hợp đồng bảo hiểm',
    'buy first pay later' => 'Mua trước trả sau',
    'discount code' => 'Mã giảm giá',
    'my coin management' => 'Quản lý xu của tôi',
    'my bookcare' => 'Bookcare của tôi',

    //thông tin cá nhân, họ và tên, nickname, ngày sinh, giới tính, quốc tịch, số điện thoại và email, số điện thoại, địa chỉ email, bảo mật, đổi mật khẩu, thiết lập mã pin, liên kết mạng xã hội, lưu thay đổi

    ];
